# Handoff: Devigo — Landing + Panel de boletos

## Resumen

Devigo es una plataforma cuantitativa de apuestas deportivas: elimina el margen de la casa
(vig) de cualquier mercado, reconstruye la cuota justa, calcula la probabilidad conjunta de
una combinada con correlación, y liquida el boleto 10.000 veces por Montecarlo para reportar
varianza y riesgo de caída.

Dos pantallas en este paquete:

1. **Landing** — página de conversión, tono confrontacional (tú contra la casa).
2. **Panel** — tablero de mercados en vivo + constructor de boletos con cálculo en tiempo real.

Ambas son bilingües ES/EN con conmutador persistente.

---

## Sobre los archivos de diseño

Los `.dc.html` de este paquete son **referencias de diseño hechas en HTML**: prototipos que
muestran la apariencia y el comportamiento buscados, **no código de producción para copiar tal
cual**. La tarea es **recrear estos diseños en el entorno del codebase destino** (React,
Next.js, Vue, SwiftUI, nativo…) con sus patrones y librerías establecidos. Este repositorio ya
trae un scaffold Next.js + Turborepo pensado para eso — úsalo como destino salvo que el equipo
prefiera otro.

Los archivos `.dc.html` llevan un runtime propio (`support.js`) que **no debe portarse**.
Lo que importa de ellos es: el marcado, los estilos inline exactos, y la lógica de la clase
`Component` (que es JavaScript plano y sí es portable casi literalmente a un hook o store).

## Fidelidad

**Alta fidelidad (hifi).** Colores, tipografía, espaciado e interacciones son definitivos.
Recréalo píxel a píxel. Todos los valores hex, tamaños y radios de este documento son los
reales usados en el prototipo.

---

## Sistema de diseño

### Paleta

Fondo y superficies — escala Zinc/Slate oscura, nunca negro puro salvo el lienzo:

| Uso | Hex |
| --- | --- |
| Lienzo de página | `#09090b` |
| Sección alterna (bandas 01/03) | `#0b0b0e` |
| Panel hundido / terminal | `#0c0c10` |
| Tarjeta elevada | `#101014` |
| Tarjeta interior / botón inactivo | `#141419` |
| Botón secundario | `#18181b` |
| Borde sutil (divisor interno) | `#17171b` |
| Borde de tarjeta | `#1c1c21` |
| Borde de control | `#232329` |
| Borde de control (hover) | `#27272a` → `#3f3f46` |

Texto:

| Uso | Hex |
| --- | --- |
| Primario | `#f4f4f5` |
| Secundario (párrafos) | `#a1a1aa` |
| Terciario (etiquetas) | `#71717a` |
| Apagado (metadatos, ejes) | `#52525b` |
| Sobre acento esmeralda | `#052e21` |

Acentos:

| Uso | Hex |
| --- | --- |
| Esmeralda (EV positivo, CTA) | `#34d399` |
| Esmeralda claro (hover, texto sobre fondo verde) | `#6ee7b7` |
| Esmeralda profundo (fondo de estado positivo) | `#082f24` |
| Esmeralda marca (fondo de logo, planes destacados) | `#0d1f19` |
| Borde esmeralda | `#0f5c43` · activo `#0f9d6e` · sutil `#1f4237` |
| Ámbar (riesgo alto, correlación ≥30%) | `#f59e0b` |
| Ámbar borde | `#4a3410` |
| Rojo (EV negativo, eliminar) | `#f43f5e` |
| Rojo fondo / borde / texto | `#2a1116` / `#7f1d3a` / `#fda4af` |
| Azul (cuota justa, modelo activo) | `#38bdf8` |
| Barra neutra de histograma | `#3f3f46` |
| Texto de estado positivo | `#a7f3d0` |

**Regla semántica del color, no negociable:** esmeralda = valor esperado positivo; ámbar =
riesgo/varianza alta; rojo = expectativa negativa; azul = valor calculado por el modelo (cuota
justa). Nunca uses esmeralda como decoración.

### Tipografía

Dos familias de Google Fonts, cargadas juntas:

```
https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600;700&family=Geist+Mono:wght@400;500;600&display=swap
```

- **Geist** — todo el texto de interfaz. Fallback: `system-ui, sans-serif`.
- **Geist Mono** — **todos los números sin excepción** (cuotas, porcentajes, importes,
  percentiles), más etiquetas técnicas, badges y el terminal. Fallback: `ui-monospace, monospace`.

Escala tipográfica real del prototipo:

| Rol | Tamaño | Peso | Tracking | Notas |
| --- | --- | --- | --- | --- |
| H1 hero | 62px | 600 | -0.035em | `line-height:1.03`, `text-wrap:balance` |
| H2 sección | 38px | 600 | -0.03em | `line-height:1.1` |
| H2 CTA final | 30px | 600 | -0.025em | |
| Cifra grande (métrica hero) | 26px | 600 | — | Mono |
| Cifra de panel (EV, Kelly…) | 24px | 600 | — | Mono |
| Cifra de KPI | 22px | 600 | — | Mono |
| Cifra de tarjeta pequeña | 17px | 600 | — | Mono |
| Cuota en botón de mercado | 15px | 600 | — | Mono |
| Párrafo hero | 17px | 400 | — | `line-height:1.6`, `text-wrap:pretty` |
| Párrafo sección | 15.5px | 400 | — | `line-height:1.6` |
| Cuerpo de tarjeta | 13px | 400 | — | `line-height:1.6` |
| Nav / etiqueta | 13px | 400–500 | — | |
| Etiqueta de campo | 11.5–12.5px | 400 | — | |
| Etiqueta técnica en mayúsculas | 10–11px | 500–600 | .04–.08em | Mono, `text-transform:uppercase` |
| Metadato mono | 10–11px | 400 | — | |

### Espaciado, radios, sombras

- Escala de espaciado: **2, 3, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 32, 36, 40, 44, 56, 72, 88** px.
- Radios: **4** (badge diminuto) · **5–6** (chip, avatar) · **7** (botón compacto) · **8** (botón,
  grupo de idioma) · **9** (caja de veredicto, CTA de plan) · **10** (botón grande, fila de
  selección) · **12** (KPI, panel interior) · **14** (tarjeta de sección) · **16** (tarjeta de
  plan) · **18** (tarjeta hero, banda de licencia) · **999** (pill).
- Única sombra del sistema: `0 40px 80px -40px #000` en la tarjeta hero. Nada más lleva sombra —
  la jerarquía se construye con bordes y niveles de superficie.
- Cabeceras pegajosas: `background: rgba(9,9,11,.85–.88)` + `backdrop-filter: blur(12–14px)`.

### Marca

Monograma: cuadrado redondeado de **28×28** (26×26 en el panel), `border-radius:9px`,
fondo `#0d1f19`, borde `1px #0f5c43`. Dentro, la letra **D** en Geist Mono 600 a 15px color
`#34d399`, y encima una barra absoluta de **1.5px** en `#34d399` con `border-radius:1px`,
posicionada `left:5px; right:5px; top:13.5px` — la barra tacha la D: **el margen eliminado**.
Junto al monograma, "Devigo" en Geist 600, 15px, `letter-spacing:-.015em`.

### Movimiento

Solo tres animaciones, todas funcionales:

- Punto de señal en vivo: `@keyframes` opacidad 1 → .3 → 1, **2s ease-in-out infinite**.
- Barras de supervivencia: `transition: width .35s cubic-bezier(.4,0,.2,1)`.
- Barras del histograma: `transition: height .35s cubic-bezier(.4,0,.2,1)`.

Sin animaciones de entrada, sin parallax, sin gradientes animados.

---

## Pantalla 1 — Landing (`Devigo Landing.dc.html`)

### Cabecera

Pegajosa, `z-index:30`, altura **64px**, padding `0 40px`, borde inferior `1px #17171b`.
`display:flex; justify-content:space-between`. Izquierda: monograma + wordmark. Derecha: nav
`display:flex; align-items:center; gap:24px; flex-wrap:wrap; justify-content:flex-end`.

**Crítico:** cada enlace de nav, el grupo de idioma y el CTA llevan
`white-space:nowrap; flex-shrink:0`. Sin esto, las etiquetas en español ("Abrir el panel") se
parten y se recortan. Ya fue un bug real en este prototipo.

Conmutador de idioma: contenedor `display:flex; padding:2px; background:#141419; border:1px solid #232329; border-radius:8px`.
Cada botón: Mono 10.5px/600, padding `4px 9px`, `border-radius:6px`. Activo: fondo `#34d399`,
texto `#052e21`. Inactivo: fondo transparente, texto `#71717a`.

CTA de cabecera: padding `8px 15px`, radio 8, fondo `#34d399`, texto `#052e21` 12.5px/600.

### Hero

Grid `minmax(0,1.05fr) minmax(0,.95fr)`, `gap:56px`, padding `88px 40px 72px`,
`max-width:1360px; margin:0 auto`.

Columna izquierda, en orden:

1. **Pill de badge** — `display:inline-flex; gap:8px; padding:5px 11px`, borde `1px #1f4237`,
   fondo `#082f24`, `border-radius:999px`, Mono 11px `#6ee7b7`, `white-space:nowrap`.
   Punto pulsante de 5px `#34d399` a la izquierda.
   Texto ES: `MÉTODO DE SHIN · 10.000 SIMULACIONES POR BOLETO`.
   Texto EN: `SHIN DE-VIG · 10,000 SIMULATIONS PER TICKET`.
2. **H1** — `margin-top:22px`, 62px/600, `line-height:1.03`, `letter-spacing:-.035em`.
   Dos líneas separadas por `<br>`; la segunda en `#34d399`.
   ES: "La casa ya cobró" / "antes del saque inicial."
   EN: "The book got paid" / "before kickoff."
3. **Párrafo** — `max-width:560px`, 17px, `line-height:1.6`, `#a1a1aa`, `text-wrap:pretty`.
   ES: "Cada cuota que aceptas lleva dentro la comisión de la casa. Devigo la arranca con el
   método de Shin, reconstruye la línea real y liquida tu combinada 10.000 veces antes de que
   arriesgues un euro."
4. **Botones** — `display:flex; gap:12px; margin-top:32px`. Primario: padding `13px 22px`,
   radio 10, fondo `#34d399`, texto `#052e21` 14px/600. Secundario: mismo tamaño, fondo
   transparente, borde `1px #27272a`, texto `#f4f4f5` 14px/500.
5. **Fila de métricas** — `display:flex; gap:36px; margin-top:44px; padding-top:26px`,
   borde superior `1px #17171b`. Tres métricas: cifra Mono 26px/600 + etiqueta 12px `#71717a`
   con `max-width:170px; line-height:1.4`. La del medio (`+3,1%`) va en `#34d399`.
   ES: 4,7% "margen mediano que le quitamos a la casa" · +3,1% "CLV sobre 41.000 apuestas
   registradas" · 100% "cobertura de tests en el núcleo".

Columna derecha — **tarjeta de boleto**: `padding:18px`, `border-radius:18px`,
`background:linear-gradient(180deg,#111116,#0c0c10)`, borde `1px #1f1f25`,
sombra `0 40px 80px -40px #000`. Contiene:

- Fila de encabezado Mono 11px: título a la izquierda (`#71717a`), `+EV 6,42%` a la derecha (`#34d399`).
- Cuatro filas de selección: `display:flex; justify-content:space-between; padding:11px 13px`,
  fondo `#141419`, borde `1px #232329`, radio 10. Cada una lleva etiqueta 12.5px/500, una
  barra de supervivencia de **120×4px** (pista `#232329`, radio 2) y la cuota en Mono 14px/600.
- Grid de tres estadísticas (`repeat(3,1fr)`, gap 8): Cuota `13,84` blanco · Justa `13,01`
  en `#38bdf8` · Kelly `38 €` en `#34d399` sobre fondo `#082f24` con borde `#0f5c43`.
- Histograma: 28 barras, `flex:1` cada una, gap 2px, alto de caja 56px, radio superior 2px.
  Las 19 primeras en `#3f3f46` (pérdida), el resto en `#34d399` (ganancia).

### Sección 01 — Motor (`#engine`)

Fondo `#0b0b0e`, padding `72px 40px`, borde superior `1px #17171b`.
Kicker Mono 11px `#34d399` `letter-spacing:.08em` → H2 38px → párrafo, todo en
`max-width:660px`. Debajo, grid `repeat(auto-fit,minmax(250px,1fr))` con gap 14 y **cinco
tarjetas de módulo**: padding 20, fondo `#101014`, borde `1px #1c1c21`, radio 14,
hover `border-color:#2c2c34`. Cada una: nombre de archivo Mono 11px `#34d399` → título 15px/600
→ cuerpo 13px `#a1a1aa` → detalle Mono 11px `#52525b`.

Los cinco módulos son `odds.ts`, `vig.ts`, `parlay.ts`, `value.ts`, `monte-carlo.ts`
(textos exactos en el diccionario del prototipo).

### Sección 02 — Pruebas (`#proof`)

Grid `minmax(0,.9fr) minmax(0,1.1fr)`, gap 56. Izquierda: kicker, H2, párrafo y cuatro
viñetas (punto de 5px `#34d399` + texto 14px `#d4d4d8`, `line-height:1.55`).
Derecha: **ventana de terminal** — radio 14, borde `1px #1c1c21`, fondo `#0c0c10`. Barra de
título con tres círculos de 9px `#3f3f46` y la ruta en Mono 11px `#71717a`; cuerpo `<pre>`
con padding 18, Mono 12px, `line-height:1.75`, `#a1a1aa`, mostrando la salida real de
`pnpm test:cov` con la tabla de cobertura al 100%.

### Sección 03 — Precios (`#pricing`)

Fondo `#0b0b0e`. Cabecera de sección con kicker + H2 a la izquierda y nota Mono 11.5px a la
derecha. Tres planes en `repeat(auto-fit,minmax(280px,1fr))`, gap 14, cada uno
`display:flex; flex-direction:column; padding:24px; border-radius:16px`.

- Planes normales: fondo `#101014`, borde `1px #1c1c21`.
- Plan destacado (Cuantitativo / Quant): fondo `#0d1f19`, borde `1px #0f5c43`.
- Badge de plan: Mono 10px, padding `2px 7px`, radio 5, `white-space:nowrap`. Destacado
  `#6ee7b7`/`#0f5c43`; B2B `#f59e0b`/`#4a3410`; normal `#a1a1aa`/`#27272a`.
- Precio Mono 36px/600 `letter-spacing:-.02em` + periodo 13px `#71717a`.
- Lista de características: punto de 4px `#52525b` + texto 13px `#d4d4d8`.
- CTA al fondo con `margin-top:auto`, padding 11, radio 9, 13.5px/600.

Planes: **Explorador/Scout** 0 € · **Cuantitativo/Quant** 79 € (destacado) · **Sindicato/Syndicate** a medida.

### Sección — Marca blanca (`#license`)

Banda `display:flex; justify-content:space-between; flex-wrap:wrap; gap:40px; padding:36px 40px`,
radio 18, `background:linear-gradient(120deg,#0d1f19,#101014 60%)`, borde `1px #1f4237`.
H2 30px + párrafo 15px a la izquierda (`max-width:620px`), dos botones a la derecha.

### Pie

Padding `28px 40px 44px`, borde superior `1px #17171b`, `display:flex; justify-content:space-between`,
12px `#52525b`. Izquierda: aviso legal ("Herramienta de modelado, no consejo de apuestas. +18.").
Derecha: versiones de paquetes en Mono.

---

## Pantalla 2 — Panel (`Devigo Panel.dc.html`)

### Estructura

Cabecera pegajosa de **60px** + cuerpo `display:grid; grid-template-columns:minmax(0,1fr) 400px;
gap:20px; padding:20px 28px 40px; align-items:start`. La columna derecha es
`position:sticky; top:80px`.

### Cabecera

Izquierda: monograma 26px + wordmark + nav de cuatro elementos (`gap:22px`, 13px, activo
`#f4f4f5`/500, resto `#71717a`). Derecha: indicador de señal (punto pulsante + Mono 11px
"SEÑAL EN VIVO · 14 CASAS"), conmutador de idioma, y bloque de capital (avatar 22px + etiqueta
+ importe en Mono). Todos los bloques de la derecha: `white-space:nowrap; flex-shrink:0`.

### Fila de KPIs

`grid-template-columns:repeat(4,minmax(0,1fr)); gap:12px`. Cada tarjeta: padding `14px 16px`,
fondo `#101014`, borde `1px #1c1c21`, radio 12. Etiqueta 11px `#71717a` en mayúsculas con
`letter-spacing:.04em`; valor Mono 22px/600.
KPIs: Líneas escaneadas (blanco) · Con valor (`#34d399`) · Margen medio (blanco) · Modelo (`#38bdf8`).

### Tablero de mercados

Tarjeta `#101014`, borde `1px #1c1c21`, radio 14, `overflow:hidden`.
Barra superior con título 14px/600 + subtítulo 12px `#71717a` a la izquierda, y dos botones a
la derecha: "CAMBIAR MODELO" (fondo `#18181b`, borde `#27272a`, Mono 11px `#a1a1aa`) y
"BOLETO +EV AUTO" (fondo `#34d399`, texto `#052e21`, Mono 11px/600).

Cada fila de mercado: `grid-template-columns:250px minmax(0,1fr); gap:20px; padding:14px 18px`,
borde inferior `1px #17171b`.
- Izquierda: chip de liga (Mono 10px, borde `1px #27272a`, radio 4, padding `1px 5px`) + hora
  Mono 11px `#52525b`; enfrentamiento 13px/500; línea de mercado y margen 11px `#71717a`.
- Derecha: `grid-template-columns:repeat(auto-fit,minmax(160px,1fr)); gap:8px` de botones de
  selección.

**Botón de selección** — `display:flex; justify-content:space-between; padding:10px 12px`,
radio 10, hover `border-color:#3f3f46`. Tres estados:

| Estado | Fondo | Borde | Color de cuota |
| --- | --- | --- | --- |
| Seleccionado | `#082f24` | `#0f9d6e` | `#34d399` |
| Con valor (ventaja ≥ umbral) | `#141419` | `#1f4237` | `#f4f4f5` |
| Normal | `#141419` | `#232329` | `#f4f4f5` |

Dentro: etiqueta 12.5px/500 con `text-overflow:ellipsis`; subtexto Mono 10.5px con la cuota
justa y la ventaja (verde `#34d399` si tiene valor, `#a1a1aa` si es neutra, `#71717a` si la
ventaja es peor que -4%); cuota Mono 15px/600 a la derecha.

### Panel de boleto (columna derecha)

Tarjeta con cabecera (título + botón VACIAR que pasa a `#f43f5e` en hover).

**Estado vacío:** padding `34px 20px`, centrado, 12.5px `#52525b`, `line-height:1.6`.

**Fila de selección del boleto:** padding `12px 16px`, borde inferior `1px #17171b`.
Etiqueta + metadatos Mono 10.5px `#71717a`; cuota Mono 13.5px/600 y botón × de 18px.
Debajo, barra de supervivencia: pista `flex:1; height:5px; border-radius:3px; background:#1c1c21`,
relleno coloreado por umbral (**>40% `#34d399`, >15% `#f59e0b`, resto `#f43f5e`**) con
transición de `.35s`, y el porcentaje en Mono 10px a la derecha en una columna fija de 56px.

**Controles:** dos filas `display:flex; gap:10px`, etiqueta de 62px, `<input type="range">`
(`flex:1`) y valor Mono 13px/600 en columna fija de 66px alineada a la derecha.
Importe: 5–250 paso 5, `accent-color:#34d399`. Correlación: 0–60% paso 5,
`accent-color:#f59e0b`; el valor pasa a ámbar a partir del 30%.

**Cuadrícula de resultados:** `grid-template-columns:1fr 1fr`, celdas de `14px 16px` separadas
por bordes de `1px #1c1c21`. Etiqueta 10.5px `#71717a` en mayúsculas `letter-spacing:.05em`;
cifra Mono 24px/600; subtexto Mono 11px `#52525b`.
Cuota combinada (blanca) · Cuota justa (`#38bdf8`) · Valor esperado (verde si >0, `#f43f5e` si
no) · Kelly (blanca, con el porcentaje fraccionado en la etiqueta).

**Bloque Montecarlo:** encabezado con título en mayúsculas y tasa de acierto; histograma de
**26 barras** (`flex:1`, gap 2, alto 64px, `min-height:2px`, radio superior 2) — barra verde
`#34d399` si su bin cae en beneficio, `#3f3f46` si cae en pérdida; eje inferior con p05,
mediana y p95 en Mono 10px `#52525b`.

**Caja de veredicto:** padding `10px 12px`, radio 9, 12px, `line-height:1.5`.
Positiva: fondo `#082f24`, borde `#0f5c43`, texto `#a7f3d0`.
Negativa: fondo `#2a1116`, borde `#7f1d3a`, texto `#fda4af`.
Inactiva: fondo `#141419`, borde `#232329`, texto `#a1a1aa`.

---

## Interacciones y comportamiento

| Acción | Resultado |
| --- | --- |
| Clic en botón de selección | Alterna esa selección en el boleto; toda la columna derecha se recalcula de forma síncrona |
| Clic en "CAMBIAR MODELO" | Cicla shin → multiplicativo → aditivo; recalcula cuotas justas, ventajas, KPIs y el boleto entero |
| Clic en "BOLETO +EV AUTO" | Selecciona las primeras 4 selecciones con ventaja ≥ umbral |
| Clic en "VACIAR" | Vacía el boleto y vuelve al estado inactivo |
| Clic en × de una selección | Quita esa selección |
| Arrastrar importe | Reescala valor esperado, Kelly y el eje del histograma |
| Arrastrar correlación | Recalcula la probabilidad conjunta y vuelve a correr las 10.000 simulaciones |
| Clic en ES/EN | Cambia idioma, formatos numéricos y moneda; persiste en `localStorage` |

Sin estados de carga (todo es cálculo local y síncrono). Sin validación de formularios: los
únicos controles son deslizadores con rango acotado.

**Rendimiento:** las 10.000 iteraciones corren en el hilo principal en unos pocos milisegundos
con un PRNG xorshift y un `Float64Array`. En producción, si añades más selecciones o corres la
simulación en cada `input` del deslizador, muévela a un Web Worker o aplica debounce de ~80 ms
en `onInput` — no la conviertas en llamada al servidor: la reproducibilidad local es parte del
argumento de venta.

**Responsive:** el prototipo está diseñado para escritorio (≥1100px). Para producción:
por debajo de 1100px la rejilla de dos columnas del panel colapsa a una y el boleto pasa a una
hoja inferior fija; por debajo de 768px las filas de mercado apilan la información del partido
sobre los botones de selección, y los KPIs pasan a 2×2. La nav de la landing debe colapsar a
menú; el hero pasa a una columna con la tarjeta debajo. **Cualquier objetivo táctil, mínimo 44px.**

## Estado

Estado del panel (cinco valores, todo local):

```ts
{
  lang: 'es' | 'en' | null,   // null = usa el prop defaultLocale
  selected: string[],          // ids de selección, en orden de adición
  stake: number,               // 5–250
  corr: number,                // 0–60 (porcentaje entero)
  methodIndex: number,         // 0=shin, 1=multiplicativo, 2=aditivo
}
```

Todo lo demás es derivado y debe calcularse en el render (o en un `useMemo`), nunca duplicarse
en estado: cuotas justas, ventajas, probabilidad conjunta, valor esperado, Kelly, simulación,
histograma y veredicto. El idioma es el único valor que se persiste (`localStorage`, clave
`devigo:lang`).

En producción, sustituye los mercados fijos por el feed real vía `@devigo/adapters`; la forma
del dato ya coincide (`OddsFeedEvent` → `Runner[]`).

## Tokens de diseño

Todo lo anterior está condensado en `packages/ui/src/tokens.ts`. Si el codebase destino ya
tiene un sistema de diseño, **mapea a sus tokens en vez de importar estos** — pero conserva la
semántica de color (esmeralda=EV+, ámbar=riesgo, rojo=EV−, azul=modelo) y el uso obligatorio de
la tipografía monoespaciada para cifras.

## Activos

Ninguno. No hay imágenes, ni iconos, ni SVG: la interfaz completa se construye con texto,
bordes y `div`s de color. El monograma son dos elementos posicionados. Los gráficos son `div`s
con altura porcentual — sin librería de charting, y no hace falta añadir una.

Si el equipo introduce iconos, el brief original pedía **Lucide** (`lucide-react`), a 16px con
`stroke-width:1.5`, color heredado del texto.

---

## Archivos de este paquete

| Archivo | Qué es |
| --- | --- |
| `Devigo Landing.dc.html` | Referencia de diseño de la landing |
| `Devigo Panel.dc.html` | Referencia de diseño del panel |
| `support.js` | Runtime del prototipo. **No portar.** Solo permite abrir los `.dc.html` en el navegador |
| `code/` | El monorepo Turborepo real, listo para `pnpm install` |

### Qué hay ya en `code/` y no hay que reescribir

```
packages/core/        Matemáticas puras, cero dependencias, 5 suites de test
  odds.ts             Conversión decimal/americana/fraccionaria, margen de la casa
  vig.ts              De-vig multiplicativo, aditivo y de Shin (resolución iterativa de z)
  parlay.ts           Acumulación de cuotas, probabilidad conjunta con correlación, supervivencia
  value.ts            Valor esperado, ventaja, Kelly fraccionado, escáner de valor
  monte-carlo.ts      Simulación con semilla, percentiles, caída máxima, decaimiento
packages/i18n/        Diccionarios ES/EN tipados + formateadores Intl
packages/adapters/    Interfaz OddsAdapter + implementación de The Odds API
packages/ui/          Tokens de diseño
apps/web/             Scaffold Next.js App Router + Tailwind
```

**La lógica del prototipo es una reimplementación en línea de `@devigo/core`.** Al portar a
Next.js, **borra esa copia y llama al paquete** — `analyzeTicket()`, `simulateTicket()`,
`devig()` y `scanValueBets()` ya hacen exactamente lo mismo, con tests. El hook
`apps/web/src/lib/ticket-store.ts` es el punto de partida.

## Orden de trabajo sugerido

1. `pnpm install` y `pnpm test:cov` — confirma que el núcleo pasa con cobertura al 100%.
2. Configura fuentes (`next/font` con Geist y Geist Mono) y los tokens en `tailwind.config.ts`.
3. Construye el panel primero: es donde vive el producto y donde el diseño es más denso.
   Empieza por el tablero de mercados, luego el boleto, luego la cuadrícula de resultados.
4. Sustituye los mercados fijos por `@devigo/adapters` detrás de un route handler que guarde
   la clave de API en el servidor.
5. La landing al final: es marcado estático más el conmutador de idioma.
6. Auditoría de responsive y de objetivos táctiles antes de dar por cerrado.

## Advertencias

- **Los datos de mercado del prototipo son inventados**, igual que las métricas de la landing
  (4,7% / +3,1% / 41.000 apuestas). Sustitúyelas por cifras reales o quítalas antes de publicar:
  son afirmaciones de rendimiento financiero.
- El aviso legal del pie y el "+18" son obligatorios en la mayoría de jurisdicciones. No los quites.
- `riskOfRuin` en `monte-carlo.ts` es hoy un flag binario, no una probabilidad. Si lo expones
  en la interfaz, conviértelo antes en una fracción sobre trayectorias repetidas.
- El de-vig de Shin necesita **tres o más participantes** para que z sea significativo; en
  mercados de dos vías cae a multiplicativo por diseño. No es un bug.
