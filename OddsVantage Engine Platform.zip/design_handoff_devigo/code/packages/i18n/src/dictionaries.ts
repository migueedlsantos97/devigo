import type { Locale } from './locales.js';

/** Every UI string. Adding a key without translating it is a type error. */
export interface Dictionary {
  readonly nav: { engine: string; proof: string; pricing: string; whiteLabel: string; console: string };
  readonly hero: { badge: string; h1a: string; h1b: string; body: string; ctaPrimary: string; ctaSecondary: string };
  readonly metrics: { margin: string; clv: string; coverage: string };
  readonly ticket: { title: string; empty: string; clear: string; stake: string; correlation: string; legOne: string; legMany: string };
  readonly stats: {
    combinedPrice: string; fairPrice: string; expectedValue: string; kelly: string;
    joint: string; perUnit: string; ofBankroll: string; noLegs: string;
  };
  readonly sim: { title: string; hit: string; median: string; runs: string };
  readonly board: { title: string; subtitle: string; switchModel: string; autoTicket: string; scanned: string; valueFound: string; avgMargin: string; model: string; margin: string; fair: string };
  readonly verdict: { positive: (edge: string) => string; heavy: (hit: string) => string; sized: string; negative: (hold: string) => string; idle: string };
  readonly footer: { legal: string };
}

const es: Dictionary = {
  nav: { engine: 'Motor', proof: 'Pruebas', pricing: 'Precios', whiteLabel: 'Marca blanca', console: 'Abrir el panel' },
  hero: {
    badge: 'MÉTODO DE SHIN · 10.000 SIMULACIONES POR BOLETO',
    h1a: 'La casa ya cobró',
    h1b: 'antes del saque inicial.',
    body: 'Cada cuota que aceptas lleva la comisión de la casa metida dentro. Devigo la arranca con el método de Shin, reconstruye la línea real y liquida tu combinada 10.000 veces antes de que arriesgues un euro.',
    ctaPrimary: 'Construir un boleto', ctaSecondary: 'Leer la especificación',
  },
  metrics: { margin: 'margen mediano eliminado', clv: 'CLV sobre 41.000 apuestas registradas', coverage: 'cobertura de tests en el núcleo' },
  ticket: { title: 'Boleto', empty: 'Añade líneas desde el tablero. La probabilidad conjunta, la correlación y la varianza se recalculan en cada clic.', clear: 'VACIAR', stake: 'Importe', correlation: 'Correl.', legOne: 'selección', legMany: 'selecciones' },
  stats: { combinedPrice: 'Cuota combinada', fairPrice: 'Cuota justa', expectedValue: 'Valor esperado', kelly: 'Kelly', joint: 'conjunta', perUnit: 'por unidad', ofBankroll: 'del capital', noLegs: 'sin selecciones' },
  sim: { title: 'Montecarlo', hit: 'acierto', median: 'mediana', runs: 'simulaciones' },
  board: { title: 'Tablero de mercados', subtitle: 'cuotas justas sin margen, calculadas con', switchModel: 'CAMBIAR MODELO', autoTicket: 'BOLETO +EV AUTO', scanned: 'Líneas escaneadas', valueFound: 'Con valor', avgMargin: 'Margen medio', model: 'Modelo', margin: 'margen', fair: 'justa' },
  verdict: {
    positive: (edge) => 'Expectativa positiva: ' + edge + ' de ventaja sobre la línea justa.',
    heavy: (hit) => ' La varianza es alta — solo ' + hit + ' de los boletos simulados cobran. No superes el importe de Kelly.',
    sized: ' El importe de Kelly mantiene la caída máxima dentro de tu tolerancia.',
    negative: (hold) => 'Expectativa negativa: la casa se queda con ' + hold + ' en esta combinación. Quita la selección más débil o espera mejor línea.',
    idle: 'El deslizador de correlación modela selecciones que comparten desenlace. Todo el cálculo corre sobre probabilidades justas, nunca sobre la cuota de la casa.',
  },
  footer: { legal: 'Herramienta de modelado, no consejo de apuestas. +18.' },
};

const en: Dictionary = {
  nav: { engine: 'Engine', proof: 'Proof', pricing: 'Pricing', whiteLabel: 'White-label', console: 'Open the console' },
  hero: {
    badge: 'SHIN DE-VIG · 10,000 SIMULATIONS PER TICKET',
    h1a: 'The book got paid',
    h1b: 'before kickoff.',
    body: "Every price you take has the book's commission buried inside it. Devigo strips it with Shin's method, rebuilds the real line, and settles your parlay 10,000 times before you risk a cent.",
    ctaPrimary: 'Build a ticket', ctaSecondary: 'Read the engine spec',
  },
  metrics: { margin: 'median margin removed', clv: 'CLV over 41k logged bets', coverage: 'unit-test coverage on core' },
  ticket: { title: 'Ticket', empty: 'Add lines from the board. Joint probability, correlation and variance recompute on every click.', clear: 'CLEAR', stake: 'Stake', correlation: 'Corr.', legOne: 'leg', legMany: 'legs' },
  stats: { combinedPrice: 'Combined price', fairPrice: 'Fair price', expectedValue: 'Expected value', kelly: 'Kelly', joint: 'joint', perUnit: 'per unit', ofBankroll: 'of bankroll', noLegs: 'no legs' },
  sim: { title: 'Monte Carlo', hit: 'hit', median: 'median', runs: 'runs' },
  board: { title: 'Market board', subtitle: 'fair prices de-vigged with', switchModel: 'SWITCH MODEL', autoTicket: 'AUTO +EV TICKET', scanned: 'Scanned lines', valueFound: '+EV found', avgMargin: 'Avg book margin', model: 'De-vig model', margin: 'margin', fair: 'fair' },
  verdict: {
    positive: (edge) => 'Positive expectation: ' + edge + ' edge over the fair line.',
    heavy: (hit) => ' Variance is heavy — only ' + hit + ' of simulated tickets cash. Stake at or below the Kelly figure.',
    sized: ' A Kelly-sized stake keeps drawdown inside tolerance.',
    negative: (hold) => 'Negative expectation: the book holds ' + hold + ' on this combination. Drop the weakest leg or wait for a better line.',
    idle: 'The correlation slider models legs that share an outcome. All maths runs on fair de-vigged probabilities, never on the book price.',
  },
  footer: { legal: 'Modelling tool, not betting advice. 18+.' },
};

export const DICTIONARIES: Record<Locale, Dictionary> = { es, en };
