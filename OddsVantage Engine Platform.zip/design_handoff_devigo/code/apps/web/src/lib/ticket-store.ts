'use client';

import { useMemo, useState } from 'react';
import { analyzeTicket, simulateTicket, type Leg } from '@devigo/core';

export const useTicket = (initial: Leg[] = []) => {
  const [legs, setLegs] = useState<Leg[]>(initial);
  const [stake, setStake] = useState(25);

  const analysis = useMemo(() => (legs.length ? analyzeTicket(legs) : null), [legs]);
  const simulation = useMemo(
    () => (legs.length ? simulateTicket(legs, { iterations: 10_000, stake, seed: 1337 }) : null),
    [legs, stake],
  );

  return {
    legs, stake, setStake, analysis, simulation,
    addLeg: (leg: Leg) => setLegs((prev) => (prev.some((l) => l.id === leg.id) ? prev : [...prev, leg])),
    removeLeg: (id: string) => setLegs((prev) => prev.filter((l) => l.id !== id)),
    clear: () => setLegs([]),
  };
};
