import type { ReactNode } from 'react';
import './globals.css';

export const metadata = { title: 'Devigo', description: 'Quantitative +EV ticket construction' };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-zinc-950 text-zinc-100 antialiased">{children}</body>
    </html>
  );
}
