import type { Config } from 'tailwindcss';

export default {
  content: ['./src/**/*.{ts,tsx}', '../../packages/ui/src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ev: { DEFAULT: '#34d399', dim: '#065f46' },
        risk: '#f59e0b',
        line: '#232329',
      },
      fontFamily: { sans: ['Geist', 'system-ui', 'sans-serif'], mono: ['Geist Mono', 'monospace'] },
    },
  },
  plugins: [],
} satisfies Config;
