# Devigo

Turborepo monorepo for a quantitative +EV betting platform.

```
apps/
  web/                Next.js App Router dashboard + landing
packages/
  core/               @devigo/core  — pure maths, zero deps, 100% covered
  adapters/           @devigo/adapters — odds feed normalisation
  ui/                 @devigo/ui — shared tokens/components
```

## @devigo/core

| Module | Responsibility |
| --- | --- |
| `odds.ts` | Decimal / American / fractional conversion, implied probability, book margin |
| `vig.ts` | Multiplicative, additive and Shin (1993) margin removal |
| `parlay.ts` | Price accumulation, correlation-matrix-adjusted joint probability, survival curve |
| `value.ts` | EV, edge, fractional Kelly, value-bet scanner |
| `monte-carlo.ts` | Seeded 10k-iteration ticket settlement, variance, drawdown, decay |

```bash
pnpm install
pnpm test:cov     # vitest, 100% line/branch/function thresholds on core
pnpm dev
```

Design reference: `Devigo Landing.dc.html`, `Devigo Dashboard.dc.html`.
